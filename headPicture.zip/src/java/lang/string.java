package java.lang;

public class string {
}
