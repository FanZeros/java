package com.company;
import java.util.Scanner;
public class test{
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("请输入");
        int p = scan.nextInt();//
        int a,b;


        for (int i = 1; i <= p; i++) {
            for (int j = 1; j <= i; j++) {
                System.out.print(j+"*"+i+"="+j*i+" " );

            }
            System.out.println();
        }



    }
}
