package com.company;
import java.util.Random;
import java.util.Scanner;

public class RubbishEnglish {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Please input your initial English");
        String password = scan.nextLine();// 获取用户输入
        char[] array = password.toCharArray();// 获取字符数组
        char[] word= new char [100];
int n=-1,a=0,b=0,length,l;
        char aaa;
        for (int i = 0; i < array.length; i++) {// 遍历字符数组
            word[(i-n)]=array[i];
length=array[i];
l=0;
if (length==63||length==46||length==44||length==33||length==32){l=1;}
            if ( l==1&&(i-n>3)) {
                //n+1~i
                if ((i-n)==5) {
                    aaa = array[n+2];
                    array[n+2] = array[n+3];
                    array[n+3] = aaa;
                    n = i;
                }else {
                    if ((i - n) == 6) {
                        aaa = array[n+2];
                        array[n+2] = array[n+4];
                        array[n+4] = aaa;
                        n = i;
                    } else {
                        for (int n1 = 1; n1 < 5; n1++) {
                            a = n + 2 + (int) (Math.random() * (i - n - 3));
                            b = n + 2 + (int) (Math.random() * (i - n - 3));
                            aaa = array[a];
                            array[a] = array[b];
                            array[b] = aaa;
                        }
                        n = i;
                    }
                }
            }
            if(l==1&&(i-n)<=3){n = i;}
        }
        System.out.println("Rubbish English is as follow：");
        System.err.println(new String(array));// 输出密钥
    }
}
