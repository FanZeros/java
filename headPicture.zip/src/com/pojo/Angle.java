/**
  * Copyright 2020 bejson.com 
  */
package com.pojo;

/**
 * Auto-generated: 2020-04-26 16:19:48
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Angle {

    private double yaw;
    private double pitch;
    private double roll;
    public void setYaw(double yaw) {
         this.yaw = yaw;
     }
     public double getYaw() {
         return yaw;
     }

    public void setPitch(double pitch) {
         this.pitch = pitch;
     }
     public double getPitch() {
         return pitch;
     }

    public void setRoll(double roll) {
         this.roll = roll;
     }
     public double getRoll() {
         return roll;
     }

}