/**
  * Copyright 2020 bejson.com 
  */
package com.pojo;
import java.util.List;

/**
 * Auto-generated: 2020-04-26 16:19:48
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Result {

    private double face_num;
    public Face_list[] face_list;
    public void setFace_num(int face_num) {
         this.face_num = face_num;
     }
     public double getFace_num() {
         return face_num;
     }

    public void setFace_list(Face_list[] face_list) {
         this.face_list = face_list;
     }
     public Face_list[] getFace_list() {
         return face_list;
     }

}