package com.pojo;

public class Spoofing {

    private double probability;

    public void set(int probability) {
        this.probability = probability;
    }
    public double get() {
        return probability;
    }
}
