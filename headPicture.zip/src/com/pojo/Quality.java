/**
  * Copyright 2020 bejson.com 
  */
package com.pojo;

/**
 * Auto-generated: 2020-04-26 16:19:48
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Quality {

    private Occlusion occlusion;
    private double blur;
    private double illumination;
    private double completeness;
    public void setOcclusion(Occlusion occlusion) {
         this.occlusion = occlusion;
     }
     public Occlusion getOcclusion() {
         return occlusion;
     }

    public void setBlur(int blur) {
         this.blur = blur;
     }
     public double getBlur() {
         return blur;
     }

    public void setIllumination(int illumination) {
         this.illumination = illumination;
     }
     public double getIllumination() {
         return illumination;
     }

    public void setCompleteness(int completeness) {
         this.completeness = completeness;
     }
     public double getCompleteness() {
         return completeness;
     }

}