/**
  * Copyright 2020 bejson.com 
  */
package com.pojo;

/**
 * Auto-generated: 2020-04-26 16:19:48
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Location {

    private double left;
    private double top;
    private double width;
    private double height;
    private double rotation;
    public void setLeft(double left) {
         this.left = left;
     }
     public double getLeft() {
         return left;
     }

    public void setTop(double top) {
         this.top = top;
     }
     public double getTop() {
         return top;
     }

    public void setWidth(int width) {
         this.width = width;
     }
     public double getWidth() {
         return width;
     }

    public void setHeight(int height) {
         this.height = height;
     }
     public double getHeight() {
         return height;
     }

    public void setRotation(int rotation) {
         this.rotation = rotation;
     }
     public double getRotation() {
         return rotation;
     }

}