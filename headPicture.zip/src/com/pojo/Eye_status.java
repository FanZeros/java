/**
  * Copyright 2020 bejson.com 
  */
package com.pojo;

/**
 * Auto-generated: 2020-04-26 16:19:48
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Eye_status {

    private double left_eye;
    private double right_eye;
    public void setLeft_eye(double left_eye) {
         this.left_eye = left_eye;
     }
     public double getLeft_eye() {
         return left_eye;
     }

    public void setRight_eye(int right_eye) {
         this.right_eye = right_eye;
     }
     public double getRight_eye() {
         return right_eye;
     }

}