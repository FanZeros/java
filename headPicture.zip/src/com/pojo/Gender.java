/**
  * Copyright 2020 bejson.com 
  */
package com.pojo;

/**
 * Auto-generated: 2020-04-26 16:19:48
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Gender {

    private String type;
    private double probability;
    public void setType(String type) {
         this.type = type;
     }
     public String getType() {
         return type;
     }

    public void setProbability(int probability) {
         this.probability = probability;
     }
     public double getProbability() {
         return probability;
     }

}